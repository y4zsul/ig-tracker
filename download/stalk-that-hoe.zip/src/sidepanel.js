/**
 * Side panel UI — three screens: home, new stalk, monitor.
 *
 * Ordering honesty is the organising principle here. Instagram serves these
 * lists in ranked display order and publishes no follow date, so:
 *
 *   - A first capture is shown ALPHABETICALLY. Its true order is unknowable,
 *     and there is deliberately no way to sort it by time, because any such
 *     control would imply a chronology that does not exist.
 *   - Later captures are shown as arrivals GROUPED BY CHECK TIME. Between
 *     groups the order is real. Inside a group it is not — those accounts only
 *     share the same check — so groups are visually banded and say so.
 */
'use strict';

const $ = (id) => document.getElementById(id);
const els = {
  screenHome: $('screenHome'),
  screenNew: $('screenNew'),
  screenMon: $('screenMon'),
  screenSelf: $('screenSelf'),
  newStalkBtn: $('newStalkBtn'),
  monitorBtn: $('monitorBtn'),
  selfBtn: $('selfBtn'),

  selfTitle: $('selfTitle'),
  selfCounts: $('selfCounts'),
  selfFollowingState: $('selfFollowingState'),
  selfFollowersState: $('selfFollowersState'),
  scanFollowingBtn: $('scanFollowingBtn'),
  scanFollowersBtn: $('scanFollowersBtn'),
  selfWarn: $('selfWarn'),
  selfSpeed: $('selfSpeed'),
  selfStopBtn: $('selfStopBtn'),
  selfMode: $('selfMode'),

  username: $('username'),
  kind: $('kind'),
  speed: $('speed'),
  startBtn: $('startBtn'),
  resumeBtn: $('resumeBtn'),
  stopBtn: $('stopBtn'),

  trackSelect: $('trackSelect'),
  checkBtn: $('checkBtn'),
  monCounts: $('monCounts'),
  monStopBtn: $('monStopBtn'),
  monDeleteBtn: $('monDeleteBtn'),

  activity: $('activity'),
  progress: $('progress'),
  progressBar: $('progressBar'),
  status: $('status'),
  alert: $('alert'),
  doneMsg: $('doneMsg'),

  ver: $('ver'),
  viewport: $('viewport'),
  spacer: $('spacer'),
  rows: $('rows'),
  monList: $('monList'),
  empty: $('empty'),
};

const ROW_H =
  parseInt(getComputedStyle(document.documentElement).getPropertyValue('--row-h'), 10) || 52;
const OVERSCAN = 6;

const SPEEDS = {
  safe: { pageSize: 50, delayMs: 2000 },
  fast: { pageSize: 200, delayMs: 600 },
  max: { pageSize: 200, delayMs: 0 },
};

let screen = 'home';
let runs = [];
let tracks = [];
let activeRunId = null;
let selfId = null;

let currentId = null; // selected run (new-stalk screen)
let summary = null;
let all = []; // capture rows
let view = []; // alphabetical, filtered

let monKey = null; // selected watched list
let monData = null; // { summary, accounts, snapshots }
let pendingCheck = null; // trackKey awaiting a finished capture

// My-account screen: the two sides of my own graph, diffed against each other.
let selfFollowing = null;
let selfFollowers = null;

const nf = new Intl.NumberFormat();
const dtfFull = new Intl.DateTimeFormat(undefined, {
  weekday: 'short',
  month: 'short',
  day: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
});

function send(message) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage(message, (response) => {
        void chrome.runtime.lastError;
        resolve(response || { ok: false, error: 'No response from the extension worker.' });
      });
    } catch (_) {
      resolve({ ok: false, error: 'Extension context unavailable — reload the extension.' });
    }
  });
}

function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) =>
    c === '&' ? '&amp;' : c === '<' ? '&lt;' : c === '>' ? '&gt;' : c === '"' ? '&quot;' : '&#39;'
  );
}

const byName = (a, b) =>
  String(a.username || '').localeCompare(String(b.username || ''), undefined, {
    sensitivity: 'base',
  });

// --- screens -----------------------------------------------------------------

function show(next) {
  screen = next;
  els.screenHome.hidden = next !== 'home';
  els.screenNew.hidden = next !== 'new';
  els.screenMon.hidden = next !== 'monitor';
  els.screenSelf.hidden = next !== 'self';

  els.activity.hidden = next === 'home';
  els.viewport.hidden = next !== 'new';
  // monList is the generic scrolling results container, shared by both
  // list-rendering screens.
  els.monList.hidden = next !== 'monitor' && next !== 'self';
  if (next !== 'monitor') els.monCounts.hidden = true;
  els.empty.hidden = true;

  if (next === 'home') els.doneMsg.hidden = true;
  render();
}

// --- flat alphabetical list (virtualised) ------------------------------------

function userRowHtml(u, lead) {
  const tags = [];
  if (u.confirmed === false) {
    tags.push(
      '<span class="tag warn" title="The previous capture was short, so this may have been missed then rather than followed since">unverified</span>'
    );
  }
  if (u.isVerified) tags.push('<span class="tag v">verified</span>');
  if (u.isPrivate) tags.push('<span class="tag">private</span>');
  const handle = esc(u.username || `(id ${u.pk})`);
  const link = u.username
    ? `<a class="uname" href="https://www.instagram.com/${encodeURIComponent(
        u.username
      )}/" target="_blank" rel="noreferrer noopener">${handle}</a>`
    : `<span class="uname">${handle}</span>`;
  return (
    '<div class="item">' +
    (lead || '') +
    `<span class="who">${link}<span class="name">${esc(u.fullName) || '&nbsp;'}</span></span>` +
    `<span class="tags">${tags.join('')}</span>` +
    '</div>'
  );
}

function renderWindow() {
  const total = view.length;
  els.spacer.style.height = `${total * ROW_H}px`;
  if (total === 0) {
    els.rows.textContent = '';
    return;
  }
  const height = els.viewport.clientHeight || 400;
  const start = Math.max(0, Math.floor(els.viewport.scrollTop / ROW_H) - OVERSCAN);
  const end = Math.min(total, Math.ceil((els.viewport.scrollTop + height) / ROW_H) + OVERSCAN);
  let html = '';
  for (let i = start; i < end; i++) html += userRowHtml(view[i]);
  els.rows.style.transform = `translateY(${start * ROW_H}px)`;
  els.rows.innerHTML = html;
}

function applyFilter() {
  view = all.slice().sort(byName);
  renderWindow();
}

// --- grouped arrivals --------------------------------------------------------

/** Arrivals bucketed by the capture that first saw them, newest bucket first. */
function arrivalGroups() {
  if (!monData) return [];
  const buckets = new Map();
  for (const a of monData.accounts) {
    if (a.baseline) continue; // present at first capture — arrival time unknown
    const list = buckets.get(a.firstSeenAt) || [];
    list.push(a);
    buckets.set(a.firstSeenAt, list);
  }
  return [...buckets.entries()]
    .sort((x, y) => y[0] - x[0])
    .map(([at, list]) => ({ at, users: list.sort(byName) }));
}

/**
 * Surfaces captures that collected accounts but never became a watch, with a
 * button to adopt them. This exists because a capture going in without its
 * watch coming out is otherwise invisible and unrecoverable.
 */
async function showOrphans() {
  const res = await send({ type: 'IGFO_ORPHAN_RUNS' });
  if (!res.ok || !res.orphans.length) return;

  const rows = res.orphans
    .map(
      (o) =>
        `<button class="orphan" data-run="${esc(o.id)}">Save ${esc(
          o.username ? '@' + o.username : o.targetId
        )} · ${o.kind} · ${nf.format(o.total)} accounts</button>`
    )
    .join('');

  els.empty.innerHTML =
    `<p><strong>Nothing being watched yet.</strong></p>` +
    `<p class="fine">But ${res.orphans.length === 1 ? 'a capture' : 'some captures'} finished ` +
    `without being saved. Adopt ${res.orphans.length === 1 ? 'it' : 'them'} as a baseline:</p>` +
    `<div class="orphans">${rows}</div>`;

  for (const b of els.empty.querySelectorAll('.orphan')) {
    b.addEventListener('click', async () => {
      b.disabled = true;
      b.textContent = 'Saving…';
      const fixed = await send({ type: 'IGFO_INGEST_RUN', runId: b.dataset.run });
      if (fixed.ok) {
        monKey = fixed.key;
        await loadTracks();
        els.trackSelect.value = monKey;
        await loadMon();
        render();
      } else {
        b.textContent = fixed.error || 'Could not save';
      }
    });
  }
}

// --- my account --------------------------------------------------------------

/** Accounts currently in a list — everyone seen, minus those since departed. */
function members(track) {
  return track ? track.accounts.filter((a) => !a.goneAt) : [];
}

/**
 * Whether a captured side can be trusted for a difference.
 *
 * This matters more here than anywhere else in the app: "doesn't follow you
 * back" is computed by subtracting one list from the other, so anyone MISSING
 * from the followers capture is wrongly accused of not following you. A short
 * followers scan produces a list of false accusations, which is worse than no
 * list at all — hence the loud warning rather than a quiet asterisk.
 */
function sideQuality(track) {
  if (!track || !track.snapshots.length) return { ok: false, reason: 'never scanned' };
  const last = track.snapshots[track.snapshots.length - 1];
  const when = new Date(last.at).toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
  if (last.full === false) {
    return { ok: false, when, reason: `incomplete (${nf.format(last.count)} of ${nf.format(last.expectedTotal)})` };
  }
  return { ok: true, when, reason: `${nf.format(members(track).length)} accounts, ${when}` };
}

function renderSelf() {
  const handle =
    (selfFollowing && selfFollowing.summary.username) ||
    (selfFollowers && selfFollowers.summary.username) ||
    null;
  els.selfTitle.textContent = handle ? `@${handle}` : 'My account';

  const followingQ = sideQuality(selfFollowing);
  const followersQ = sideQuality(selfFollowers);
  els.selfFollowingState.textContent = followingQ.reason;
  els.selfFollowersState.textContent = followersQ.reason;
  els.selfFollowingState.classList.toggle('bad', !followingQ.ok);
  els.selfFollowersState.classList.toggle('bad', !followersQ.ok);

  const sum = (selfFollowers && selfFollowers.summary) || (selfFollowing && selfFollowing.summary);
  if (sum && (sum.reportedFollowers != null || sum.reportedFollowing != null)) {
    const part = (n, label) => (n == null ? '' : `<span><b>${nf.format(n)}</b>${label}</span>`);
    els.selfCounts.innerHTML =
      part(sum.reportedFollowers, 'followers') + part(sum.reportedFollowing, 'following');
    els.selfCounts.hidden = false;
  } else {
    els.selfCounts.hidden = true;
  }

  const mode = els.selfMode.value;
  const following = members(selfFollowing);

  // Preferred path: Instagram tags each row of your following list with
  // whether that account follows you back. When present it is authoritative
  // and needs no followers scan at all — which matters because the followers
  // endpoint stops serving pages well before the end on larger accounts, so a
  // subtraction against it invents people who "don't follow you back".
  const tagged = following.filter((a) => a.followsYou != null);
  const coverage = following.length ? tagged.length / following.length : 0;
  const direct = coverage >= 0.9 && following.length > 0;

  if (direct && mode !== 'fans') {
    els.selfWarn.hidden = false;
    els.selfWarn.classList.remove('bad');
    els.selfWarn.textContent =
      'Read directly from your following list — no followers scan needed, and not affected by how far the followers scan gets.';

    const list = (mode === 'notback'
      ? tagged.filter((a) => a.followsYou === false)
      : tagged.filter((a) => a.followsYou === true)
    )
      .slice()
      .sort(byName);
    paintSelfList(list, mode);
    return;
  }

  // Fallback: subtract one captured list from the other.
  if (!selfFollowing || !selfFollowers) {
    els.selfWarn.hidden = false;
    els.selfWarn.classList.remove('bad');
    els.selfWarn.textContent = direct
      ? 'Scan your followers to see who follows you that you do not follow back.'
      : 'Scan both lists to compare them. Following is quick; followers is slower because Instagram only serves 25 per page.';
    els.monList.innerHTML = '';
    els.empty.hidden = false;
    els.empty.innerHTML = '<p class="fine">Nothing to compare yet.</p>';
    return;
  }

  const followers = members(selfFollowers);
  const followerPks = new Set(followers.map((a) => a.pk));
  const followingPks = new Set(following.map((a) => a.pk));

  if (!followingQ.ok || !followersQ.ok) {
    const s = selfFollowers.snapshots[selfFollowers.snapshots.length - 1];
    const got = s ? nf.format(s.count) : '?';
    const want = s && s.expectedTotal != null ? nf.format(s.expectedTotal) : '?';
    els.selfWarn.hidden = false;
    els.selfWarn.classList.add('bad');
    els.selfWarn.textContent =
      `The followers scan reached ${got} of ${want}, so this comparison is a guess — anyone it ` +
      `never reached is listed below as not following you back, wrongly. Re-scan followers; if it ` +
      `still stops short, re-scan your following list instead, which can report follow-back ` +
      `status directly without needing followers at all.`;
  } else {
    els.selfWarn.hidden = true;
    els.selfWarn.classList.remove('bad');
  }

  let list;
  if (mode === 'notback') list = following.filter((a) => !followerPks.has(a.pk));
  else if (mode === 'fans') list = followers.filter((a) => !followingPks.has(a.pk));
  else list = following.filter((a) => followerPks.has(a.pk));

  list = list.slice().sort(byName);
  paintSelfList(list, mode);
}

function paintSelfList(list, mode) {

  if (!list.length) {
    els.monList.innerHTML = '';
    els.empty.hidden = false;
    els.empty.innerHTML = '<p><strong>Nobody here.</strong></p>';
    return;
  }

  els.empty.hidden = true;
  const label =
    mode === 'notback'
      ? `${nf.format(list.length)} you follow who don't follow you back`
      : mode === 'fans'
      ? `${nf.format(list.length)} who follow you that you don't follow back`
      : `${nf.format(list.length)} mutuals`;

  els.monList.innerHTML =
    `<div class="ghead"><span class="gtime">${esc(label)}</span></div>` +
    `<div class="gbody">${list.map((u) => userRowHtml(u)).join('')}</div>`;
}

async function loadSelf() {
  selfFollowing = null;
  selfFollowers = null;
  if (!selfId) return;
  for (const kind of ['following', 'followers']) {
    const res = await send({ type: 'IGFO_GET_TRACK', key: `${kind}:${selfId}` });
    if (res.ok) {
      const data = { summary: res.summary, accounts: res.accounts, snapshots: res.snapshots };
      if (kind === 'following') selfFollowing = data;
      else selfFollowers = data;
    }
  }
}

/** Instagram's own displayed counts for the watched account, not our tally. */
function renderCounts() {
  const s = monData && monData.summary;
  if (!s || (s.reportedFollowers == null && s.reportedFollowing == null)) {
    els.monCounts.hidden = true;
    return;
  }
  const part = (n, label) =>
    n == null ? '' : `<span><b>${nf.format(n)}</b>${label}</span>`;
  els.monCounts.innerHTML =
    part(s.reportedFollowers, 'followers') + part(s.reportedFollowing, 'following');
  els.monCounts.hidden = false;
}

function renderGroups() {
  const groups = arrivalGroups();
  const s = monData && monData.summary;

  if (!monData) {
    els.monList.innerHTML = '';
    els.empty.hidden = false;
    els.empty.innerHTML = '<p><strong>Nothing being watched yet.</strong></p>';
    // A finished capture with no watch behind it is recoverable — offer it
    // rather than leaving a dead end.
    showOrphans();
    return;
  }

  if (!groups.length) {
    els.monList.innerHTML = '';
    els.empty.hidden = false;
    els.empty.innerHTML = `<p><strong>Nobody new yet.</strong></p><p class="fine">${nf.format(
      s.baselineCount
    )} accounts were already there when you started watching on ${esc(
      new Date(s.firstSnapshotAt).toLocaleDateString()
    )} — they are not shown, because there is no way to know what order they were added in.</p>
      <p class="fine">Hit <em>Check now</em> to look again.</p>`;
    return;
  }

  els.empty.hidden = true;
  const out = [];
  groups.forEach((g, gi) => {
    const shaky = g.users.filter((u) => u.confirmed === false);
    const reason = shaky.length ? shaky[0].confirmReason : null;
    out.push(
      `<div class="ghead"><span class="gtime">${esc(dtfFull.format(new Date(g.at)))}</span>` +
        // Only the newest check gets the badge — on older groups it reads as
        // though those arrivals are new too.
        (gi === 0 ? `<span class="gcount">${nf.format(g.users.length)} new</span>` : '') +
        '</div>' +
        // The generic "no order here" caveat lives in the footer now; this
        // line survives only when there is something specific to warn about.
        (shaky.length
          ? `<div class="gnote"><b>${nf.format(shaky.length)} unverified</b>: ${esc(
              reason || 'the previous capture came up short'
            )}, so they may have been followed long ago and simply missed</div>`
          : '')
    );
    out.push('<div class="gbody">');
    for (const u of g.users) out.push(userRowHtml(u));
    out.push('</div>');
  });
  out.push(
    `<div class="gfoot">${nf.format(s.baselineCount)} accounts predate the watch and are not listed.` +
      `<br><span class="gfoot-warn">Accounts under the same date were all found by that one check — ` +
      `they are not in order relative to each other.</span></div>`
  );
  els.monList.innerHTML = out.join('');
}

// --- controls ----------------------------------------------------------------

function busyRun() {
  const a = runs.find((r) => r.id === activeRunId);
  return a && (a.status === 'running' || a.status === 'starting') ? a : null;
}

function renderControls() {
  const active = busyRun();
  const busy = !!active;

  els.startBtn.hidden = busy;
  els.stopBtn.hidden = !busy;
  els.startBtn.disabled = busy;
  els.username.disabled = busy;
  els.kind.disabled = busy;
  els.speed.disabled = busy;

  const shown = runs.find((r) => r.id === currentId);
  const canResume = !busy && !!shown && shown.resumable;
  els.resumeBtn.hidden = busy || !canResume;
  els.resumeBtn.textContent = `Resume from ${nf.format(shown ? shown.total : 0)}`;

  els.scanFollowingBtn.disabled = busy || !selfId;
  els.scanFollowersBtn.disabled = busy || !selfId;
  els.selfSpeed.disabled = busy;
  els.selfStopBtn.hidden = !busy;

  els.checkBtn.hidden = busy;
  els.monStopBtn.hidden = !busy;
  els.checkBtn.disabled = busy || !monKey;
  els.monDeleteBtn.disabled = busy || !monKey;

  els.progress.hidden = !busy;
  if (busy) {
    const known = active.expectedTotal != null && active.expectedTotal > 0;
    els.progress.classList.toggle('indeterminate', !known);
    els.progressBar.style.width = known
      ? `${Math.min(100, (active.total / active.expectedTotal) * 100).toFixed(1)}%`
      : '';
    const who = active.targetUsername ? `@${active.targetUsername}` : '…';
    // Pass number matters: a second pass re-walks the whole list from the top,
    // so without this the progress bar appears to restart for no reason.
    const passNote = active.pass > 0 ? ` · re-check ${active.pass + 1}` : '';
    els.status.textContent =
      (known
        ? `Reading ${active.kind} of ${who} — ${nf.format(active.total)} / ${nf.format(
            active.expectedTotal
          )}`
        : `Reading ${active.kind} of ${who} — ${nf.format(active.total)} so far`) + passNote;
  } else if (!els.status.dataset.sticky) {
    els.status.textContent = '';
  }

  const alerts = [];
  if (active && active.warning) alerts.push(active.warning);
  // Not when the completion panel is already showing the same message.
  if (shown && shown.error && screen === 'new' && els.doneMsg.hidden) alerts.push(shown.error);
  els.alert.hidden = alerts.length === 0;
  if (alerts.length) els.alert.textContent = alerts.join(' ');
}

function render() {
  renderControls();
  if (screen === 'new') {
    applyFilter();
    els.empty.hidden = all.length > 0 || !!busyRun();
    if (els.empty.hidden === false && !summary) {
      els.empty.innerHTML =
        '<p><strong>Pick someone to watch.</strong></p><p class="fine">Enter a username and hit Start. The first capture is the baseline.</p>';
    }
  } else if (screen === 'monitor') {
    renderCounts();
    renderGroups();
  } else if (screen === 'self') {
    renderSelf();
  }
}

// --- loading -----------------------------------------------------------------

async function loadState() {
  const res = await send({ type: 'IGFO_GET_STATE' });
  runs = res.ok ? res.runs : [];
  activeRunId = res.ok ? res.activeRunId : null;
  if (res.ok && res.selfId) selfId = res.selfId;
  renderControls();
}

async function loadTracks() {
  const res = await send({ type: 'IGFO_LIST_TRACKS' });
  tracks = res.ok ? res.tracks : [];
  tracks.sort((a, b) => (b.lastSnapshotAt || 0) - (a.lastSnapshotAt || 0));

  els.trackSelect.textContent = '';
  if (!tracks.length) {
    const o = document.createElement('option');
    o.value = '';
    o.textContent = 'Nothing watched yet';
    els.trackSelect.append(o);
    els.trackSelect.disabled = true;
    monKey = null;
    monData = null;
    return;
  }
  els.trackSelect.disabled = false;
  for (const t of tracks) {
    const o = document.createElement('option');
    o.value = t.key;
    o.textContent = `${t.username ? '@' + t.username : t.targetId} · ${t.kind} · ${nf.format(
      t.datedCount
    )} new`;
    els.trackSelect.append(o);
  }
  if (!monKey || !tracks.some((t) => t.key === monKey)) monKey = tracks[0].key;
  els.trackSelect.value = monKey;
}

async function loadMon() {
  monData = null;
  if (!monKey) return;
  const res = await send({ type: 'IGFO_GET_TRACK', key: monKey });
  if (res.ok) monData = { summary: res.summary, accounts: res.accounts, snapshots: res.snapshots };
}

async function loadRun(id) {
  currentId = id;
  summary = null;
  all = [];
  if (id) {
    const res = await send({ type: 'IGFO_GET_RUN', runId: id });
    if (res.ok) {
      summary = res.summary;
      all = res.users;
    }
  }
}

// --- live updates ------------------------------------------------------------

chrome.runtime.onMessage.addListener((message) => {
  if (!message || typeof message !== 'object') return;

  // A capture was folded into the history. This is the authoritative signal
  // that the arrivals view is out of date — no run bookkeeping involved.
  if (message.type === 'IGFO_TRACK_UPDATED') {
    (async () => {
      if (screen === 'self') {
        await loadSelf();
        render();
        return;
      }
      await loadTracks();
      if (!monKey || monKey === message.key) {
        monKey = message.key;
        els.trackSelect.value = monKey;
        await loadMon();
      }
      if (screen === 'monitor') {
        render();
        const bits = [];
        bits.push(
          message.arrived
            ? `${nf.format(message.arrived)} new since the last check.`
            : 'Nobody new since the last check.'
        );
        // Say it plainly rather than showing them as arrivals with a caveat.
        if (message.absorbed) {
          bits.push(
            `${nf.format(message.absorbed)} missed by an earlier scan — added to the baseline, not counted as new.`
          );
        }
        setStatus(bits.join(' '), true);
      }
    })();
    return;
  }

  if (message.type === 'IGFO_STATE') {
    runs = message.runs;
    activeRunId = message.activeRunId;
    if (message.selfId) selfId = message.selfId;

    const fresh = runs.find((r) => r.id === currentId);
    const finished = fresh && fresh.status !== 'running' && fresh.status !== 'starting';
    if (fresh) summary = fresh;

    // trackKey is only known once the page has resolved the target, so read it
    // off the finished run rather than guessing it at start time.
    if (finished && pendingCheck && fresh && fresh.trackKey) {
      pendingCheck = null;
      onCaptureFinished(fresh.trackKey, fresh);
      return;
    }
    if (finished) pendingCheck = null;
    render();
    return;
  }

  if (message.type !== 'IGFO_APPEND') return;
  const target = runs.find((r) => r.id === message.runId);
  if (target) Object.assign(target, message.summary);
  if (message.runId === currentId) {
    summary = message.summary;
    all = all.concat(message.users);
  }
  if (screen === 'new') render();
  else renderControls();
});

/** A capture just completed: either it was the baseline, or it is a re-check. */
async function onCaptureFinished(key, run) {
  // A scan started from the My account screen stays there — it is comparing
  // two lists, not opening a watch.
  if (screen === 'self') {
    await loadSelf();
    render();
    return;
  }

  await loadTracks();
  monKey = key;
  await loadMon();

  // Never navigate to Monitor with nothing to show there. If the capture
  // collected rows but no watch was recorded, fold it in now and carry on —
  // the user should not have to redo a capture over bookkeeping.
  if (!monData && run && run.total > 0) {
    const fixed = await send({ type: 'IGFO_INGEST_RUN', runId: run.id });
    if (fixed.ok) {
      await loadTracks();
      monKey = fixed.key;
      await loadMon();
    }
  }

  if (!monData) {
    // The completion panel carries the reason, so suppress the alert strip —
    // otherwise the same sentence appears twice, one above the other.
    els.alert.hidden = true;
    els.doneMsg.hidden = false;
    els.doneMsg.classList.add('bad');
    els.doneMsg.innerHTML =
      `<strong>Nothing was saved.</strong> ` +
      esc(
        (run && run.error) ||
          'The capture returned no accounts — the list may be private or restricted.'
      ) +
      ` <br><span class="fine">Try again; anything already collected is kept.</span>`;
    render();
    return;
  }

  const isBaseline = monData.summary.snapshotCount === 1;

  if (screen === 'new' && isBaseline) {
    els.doneMsg.hidden = false;
    els.doneMsg.classList.remove('bad');
    els.doneMsg.innerHTML =
      `<strong>Baseline saved — ${nf.format(all.length)} accounts.</strong> ` +
      `We'll keep an eye on them from now on. Come back to <em>Monitor a user</em> to see who they add.` +
      `<br><span class="fine">Listed A-Z below. Instagram does not say what order these were followed in, so this list has no chronology — only what comes next does.</span>`;
    render();
    return;
  }

  // A re-check: the arrivals are what matter, so go straight to them.
  els.doneMsg.hidden = true;
  els.doneMsg.classList.remove('bad');
  els.trackSelect.value = monKey;
  show('monitor');
}


// --- actions -----------------------------------------------------------------

function setStatus(text, sticky) {
  els.status.textContent = text;
  if (sticky) els.status.dataset.sticky = '1';
  else delete els.status.dataset.sticky;
}

async function beginCapture(usernameOrId, kind) {
  const speed = SPEEDS[els.speed.value] || SPEEDS.safe;
  els.alert.hidden = true;
  els.doneMsg.hidden = true;
  setStatus('Resolving…', true);

  const res = await send({
    type: 'IGFO_START',
    kind,
    username: usernameOrId,
    pageSize: speed.pageSize,
    delayMs: speed.delayMs,
  });

  if (!res.ok) {
    setStatus('', false);
    els.alert.hidden = false;
    els.alert.textContent = res.error || 'Could not start.';
    return false;
  }
  delete els.status.dataset.sticky;
  await loadRun(res.runId);
  await loadState();
  render();
  return true;
}

async function startNew() {
  const name = els.username.value.replace(/^@/, '').trim();
  if (!name) {
    els.username.focus();
    setStatus('Enter a username first.', true);
    return;
  }
  pendingCheck = true;
  if (!(await beginCapture(name, els.kind.value))) pendingCheck = null;
}

async function checkNow() {
  if (!monKey || !monData) return;
  const s = monData.summary;
  pendingCheck = monKey;
  await beginCapture(s.targetId || s.username, s.kind);
}

async function stopCapture() {
  els.stopBtn.disabled = true;
  els.monStopBtn.disabled = true;
  await send({ type: 'IGFO_ABORT' });
  els.stopBtn.disabled = false;
  els.monStopBtn.disabled = false;
}

async function resume() {
  if (!currentId) return;
  const speed = SPEEDS[els.speed.value] || SPEEDS.safe;
  els.resumeBtn.disabled = true;
  const res = await send({
    type: 'IGFO_RESUME',
    runId: currentId,
    pageSize: speed.pageSize,
    delayMs: speed.delayMs,
  });
  if (!res.ok) {
    els.alert.hidden = false;
    els.alert.textContent = res.error || 'Could not resume.';
  }
  await loadState();
  render();
}

// --- events ------------------------------------------------------------------

els.newStalkBtn.addEventListener('click', async () => {
  currentId = null;
  summary = null;
  all = [];
  els.doneMsg.hidden = true;
  show('new');
  els.username.focus();
});

els.monitorBtn.addEventListener('click', async () => {
  await loadTracks();
  await loadMon();
  show('monitor');
});

for (const b of document.querySelectorAll('[data-home]')) {
  b.addEventListener('click', () => show('home'));
}

els.startBtn.addEventListener('click', startNew);
els.username.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !els.startBtn.hidden) startNew();
});
els.resumeBtn.addEventListener('click', resume);
els.stopBtn.addEventListener('click', stopCapture);
els.monStopBtn.addEventListener('click', stopCapture);
els.selfStopBtn.addEventListener('click', stopCapture);
els.checkBtn.addEventListener('click', checkNow);

els.selfBtn.addEventListener('click', async () => {
  await loadState();
  await loadSelf();
  show('self');
  if (!selfId) {
    els.selfWarn.hidden = false;
    els.selfWarn.textContent =
      'Your account id is not known yet. Open a logged-in instagram.com tab, refresh it, then come back.';
  }
});

els.selfMode.addEventListener('change', () => {
  els.monList.scrollTop = 0;
  renderSelf();
});

async function scanSelf(kind) {
  if (!selfId) return;
  // beginCapture reads the pacing off the New stalk screen's select, so mirror
  // this screen's choice into it rather than keeping two sources of truth.
  els.speed.value = els.selfSpeed.value;
  pendingCheck = true;
  els.selfWarn.hidden = true;
  await beginCapture(selfId, kind);
}

els.scanFollowingBtn.addEventListener('click', () => scanSelf('following'));
els.scanFollowersBtn.addEventListener('click', () => scanSelf('followers'));

els.trackSelect.addEventListener('change', async () => {
  monKey = els.trackSelect.value;
  await loadMon();
  render();
});

els.viewport.addEventListener('scroll', renderWindow, { passive: true });
window.addEventListener('resize', renderWindow);

let deleteArmed = false;
let deleteTimer = null;
els.monDeleteBtn.addEventListener('click', async () => {
  if (!monKey) return;
  if (!deleteArmed) {
    deleteArmed = true;
    els.monDeleteBtn.classList.add('armed');
    els.monDeleteBtn.textContent = 'Sure?';
    deleteTimer = setTimeout(() => {
      deleteArmed = false;
      els.monDeleteBtn.classList.remove('armed');
      els.monDeleteBtn.innerHTML = '&#10005;';
    }, 3000);
    return;
  }
  clearTimeout(deleteTimer);
  deleteArmed = false;
  els.monDeleteBtn.classList.remove('armed');
  els.monDeleteBtn.innerHTML = '&#10005;';
  await send({ type: 'IGFO_DELETE_TRACK', key: monKey });
  monKey = null;
  await loadTracks();
  await loadMon();
  render();
});

try {
  els.ver.textContent = `v${chrome.runtime.getManifest().version}`;
} catch (_) {}

show('home');
loadState();
loadTracks();
